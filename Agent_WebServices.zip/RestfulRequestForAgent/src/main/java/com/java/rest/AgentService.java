package com.java.rest;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.Consumes;
@Path("/Agent")
public class AgentService {
	
	@POST
	@Path("/addAgent")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String addAgent(Agent agent) throws ClassNotFoundException, SQLException {
		AgentDAO dao = new AgentDAO();
		return dao.insertAgent(agent);
	}
	

	@GET
	@Path("/showAgent")
	@Produces(MediaType.APPLICATION_JSON)
	public Agent[] showAgent() throws ClassNotFoundException, SQLException {
		AgentDAO dao = new AgentDAO();
		Agent[] emps = dao.showAgent();
		return emps;
	}
	
	@GET
	@Path("/searchAgent/{agentid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Agent searchAgent(@PathParam("agentid") int agentid) throws ClassNotFoundException, SQLException {
		AgentDAO dao = new AgentDAO();
		Agent agent = dao.searchAgent(agentid);
		return agent;
	}
	@GET
	@Path("/deleteAgent/{agentid}")
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteAgent(@PathParam("agentid") int agentid) throws ClassNotFoundException, SQLException {
		AgentDAO dao = new AgentDAO();
		return dao.deleteAgent(agentid);
		
	}
}
