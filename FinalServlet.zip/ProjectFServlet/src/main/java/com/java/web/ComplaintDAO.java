package com.java.web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.java.bankingjdbc.ConnectionHelper;

import java.text.SimpleDateFormat;
public class ComplaintDAO {

	Connection connection;
	PreparedStatement pst;
    SimpleDateFormat sdformat =new SimpleDateFormat("yyyy-MM-dd");
    private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
        java.sql.Date sDate = new java.sql.Date(uDate.getTime());
        return sDate;
    }
    public String addResolve(Resolve resolve) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		 
	        
	     java.sql.Date sDate = convertUtilToSql(resolve.getComplaintDate());
	     java.sql.Date s1Date = convertUtilToSql(resolve.getResolveDate());
      
		String cmd = "Insert into Resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,Comments) "
				+ " values(?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, resolve.getComplaintID());
		pst.setDate(2,sDate);
		pst.setDate(3,s1Date);
		pst.setString(4, resolve.getResolvedBy());
		pst.setString(5, resolve.getComments());
		pst.executeUpdate();
		
		Complaint complaint=new Complaint();
		connection = ConnectionHelper.getConnection();
		cmd = "update Complaint set status='Resolve' "
				+ " where ComplaintID=?";
		connection = ConnectionHelper.getConnection();
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, resolve.getComplaintID());
		pst.executeUpdate();
		return "Account Closed...";
		
	}
   
	public int generateComplaintNo() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select max(ComplaintID)+1 ComplaintID from Complaint";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int ComplaintID = rs.getInt("ComplaintID");
		return ComplaintID;
	}
	
	
	public String addComplaint(Complaint complaint) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		 java.util.Date uDate = new java.util.Date();
	        
	     java.sql.Date sDate = convertUtilToSql(complaint.getComplaintDate());
      
		String cmd = "Insert into Complaint(ComplaintID,ComplaintType,CDescription,ComplaintDate,Severity,Status) "
				+ " values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, complaint.getComplaintID());
		pst.setString(2, complaint.getComplaintType());
		pst.setString(3, complaint.getCDescription());
		pst.setDate(4,sDate);
		pst.setString(5, complaint.getSeverity());
		pst.setString(6, complaint.getStatus());
		pst.executeUpdate();
		return "Record Inserted...";
	}
	
	public Complaint searchComplaint(int ComplaintID )throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Complaint where ComplaintID=?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, ComplaintID);
		ResultSet rs = pst.executeQuery();
		Complaint complaint = null;
		if (rs.next()) {
			
			complaint = new Complaint();
			complaint.setComplaintID(rs.getInt("ComplaintID"));
			complaint.setComplaintType(rs.getString("ComplaintType"));
			complaint.setCDescription(rs.getString("CDescription"));
			
			complaint.setComplaintDate(rs.getDate("ComplaintDate"));
			complaint.setSeverity(rs.getString("Severity"));
			complaint.setStatus(rs.getString("Status"));
		
		}
		return complaint;
	}
	
	public Complaint[] showComplaint() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Complaint order by ComplaintID";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		System.out.println(rs);
		System.out.println("#####################");
		List<Complaint> complaintList = new ArrayList<Complaint>();
		Complaint complaint = null;
		while(rs.next()) {
		
			complaint = new Complaint();
			complaint.setComplaintID(rs.getInt("ComplaintID"));
			complaint.setComplaintType(rs.getString("ComplaintType"));
			complaint.setCDescription(rs.getString("CDescription"));
			
			complaint.setComplaintDate(rs.getDate("ComplaintDate"));
			complaint.setSeverity(rs.getString("Severity"));
			complaint.setStatus(rs.getString("Status"));
			complaintList.add(complaint);
		}
		return complaintList.toArray(new Complaint[complaintList.size()]);
	}
	public Resolve[] showResolve() throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from resolve order by ComplaintID";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		System.out.println(rs);
		System.out.println("#####################");
		List<Resolve> resolveList = new ArrayList<Resolve>();
		Resolve resolve= null;
		while(rs.next()) {
			
			resolve= new Resolve();
			resolve.setComplaintID(rs.getInt("ComplaintID"));
			resolve.setComplaintDate(rs.getDate("ComplaintDate"));
			resolve.setResolveDate(rs.getDate("ResolveDate"));
			resolve.setResolvedBy(rs.getString("ResolvedBy"));
			resolve.setComments(rs.getString("Comments"));
			resolveList.add(resolve);
		}
		return resolveList.toArray(new Resolve[resolveList.size()]);
	}

}