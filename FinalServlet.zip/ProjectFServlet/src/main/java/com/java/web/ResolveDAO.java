package com.java.web;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
public class ResolveDAO{
Connection connection;
	PreparedStatement pst;
    SimpleDateFormat sdformat =new SimpleDateFormat("yyyy-MM-dd");
	
	
	 private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
	        java.sql.Date sDate = new java.sql.Date(uDate.getTime());
	        return sDate;
	    }
	public String addResolve(Resolve resolve) throws ClassNotFoundException, SQLException {
		connection = ConnectionHelper.getConnection();
		 java.util.Date uDate = new java.util.Date();
	        
	     java.sql.Date sDate = convertUtilToSql(resolve.getComplaintDate());
	     java.sql.Date s1Date = convertUtilToSql(resolve.getResolveDate());
      
		String cmd = "Insert into Resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,Comments) "
				+ " values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, resolve.getComplaintID());
		pst.setDate(4,sDate);
		pst.setDate(4,s1Date);
		pst.setString(5, resolve.getResolvedBy());
		pst.setString(6, resolve.getComments());
		pst.executeUpdate();
		return "Record Inserted...";
	}
}