package com.java.spring;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AgentSearch {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/spring/jdbc.xml");
		AgentDAO dao = (AgentDAO)ctx.getBean("agentDao");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Agent id   ");
		int Agentno = sc.nextInt();
		Agent agent= dao.searchAgent(Agentno);
		System.out.println(agent);
	}
}
