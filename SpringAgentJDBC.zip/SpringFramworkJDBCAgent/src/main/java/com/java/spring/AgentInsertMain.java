package com.java.spring;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AgentInsertMain {

	public static void main(String[] args) {
		Agent agent= new Agent();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no   ");
		agent.setAgentid(sc.nextInt());
		System.out.println("Enter Name   ");
		agent.setName(sc.next());
		System.out.println("Enter Gender   ");
		agent.setGender(sc.next());
		System.out.println("Enter city  ");
		agent.setCity(sc.next());
		System.out.println("Enter marital status  ");
		agent.setMaritalstatus(sc.nextInt());
		System.out.println("Enter Premium ");
		agent.setPremium(sc.nextDouble());
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/spring/jdbc.xml");
		AgentDAO dao = (AgentDAO)ctx.getBean("agentDao");
		System.out.println(dao.addAgent(agent));
	}
}
