package com.java.spring;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AgentDelete {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/java/spring/jdbc.xml");
		AgentDAO dao = (AgentDAO)ctx.getBean("agentDao");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter AgentId   ");
		int AgentId = sc.nextInt();
		dao.deleteAgent(AgentId);
		System.out.println("*** Record Deleted ***");
	}
}
