package com.java.web;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BooksDAO {
	Connection connection;
	PreparedStatement pst;
	public int generateid() throws SQLException {
		connection = ConnectionHelper.getConnection();
		String cmd = " select case when max(id) is NULL"
				+ " then 1 else max(id)+1 end id from books ";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int id = rs.getInt("id");
		return id;
	}
	public String addbook(Books book) throws ClassNotFoundException, SQLException {
		connection=ConnectionHelper.getConnection();
		int id = generateid();
		book.setId(id);
		String cmd = "insert into books(id,name,author,edition,dept,totalbooks)"
				+ "values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, id);
		pst.setString(2, book.getName());
		pst.setString(3, book.getAuthor());
		pst.setString(4, book.getEdition());
		pst.setString(5, book.getDept()); 
		pst.setInt(6, book.getTotalbooks());
		pst.executeUpdate();
		return "Books Inserted...";
	}
	
	public String deletebook(int id) throws ClassNotFoundException, SQLException {
		Books book = searchbooks(id);
		if (book != null) {
			connection = ConnectionHelper.getConnection();
			String cmd = "Delete from books where id=?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, id);
			pst.executeUpdate();
			return "Book Details Deleted...";
		}
		return "Book detail not Found...";
	}
	public String updatebook(Books book) throws ClassNotFoundException, SQLException {
		Books book1 = searchbooks(book.getId());
		if (book1 != null) {
			String cmd = "Update books set Name=?, author=?, edition=?, dept=?, totalbooks=? "
					+ " Where id=?";
			connection = ConnectionHelper.getConnection();
			pst = connection.prepareStatement(cmd);
			pst = connection.prepareStatement(cmd);
			pst.setString(1, book.getName());
			pst.setString(2, book.getAuthor());
			pst.setString(3, book.getEdition());
			pst.setString(4, book.getDept()); 
			pst.setInt(5, book.getTotalbooks());
			pst.setInt(6, book.getId());

			pst.executeUpdate();
			return "Book Details Updated...";
		}
		return "Book detail Not Found...";
	}
	public Books searchbooks(int id) throws SQLException, ClassNotFoundException {
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from books where id=?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, id);
		ResultSet rs = pst.executeQuery();
		Books books = null;
		if (rs.next()) {
			books= new Books();
			books.setId(rs.getInt("id"));
			books.setName(rs.getString("name"));
			books.setAuthor(rs.getString("author"));
			books.setEdition(rs.getString("edition"));
			books.setDept(rs.getString("dept"));
			books.setTotalbooks(rs.getInt("totalbooks"));
			
		}
		return books;
	}

	public Books[] showbook() throws ClassNotFoundException, SQLException {
		connection=ConnectionHelper.getConnection();
		String cmd = "select * from books";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Books> bookList = new ArrayList<Books>();
		Books book = null;
		while(rs.next()) {
			book = new Books();
			book.setId(rs.getInt("id"));
			book.setName(rs.getString("name"));
			book.setAuthor(rs.getString("author"));
			book.setEdition(rs.getString("edition"));
			book.setDept(rs.getString("dept"));
			book.setTotalbooks(rs.getInt("totalbooks"));
			bookList.add(book);
		}
	    return bookList.toArray(new Books[bookList.size()]);
	}
}