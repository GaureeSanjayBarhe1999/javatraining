export class Customer {
    public cus_id : number;
    public cus_name : string;
    public cus_ph_no : string;
    public cus_username : string;
    public pwd : string;
    public cus_email : string;

    constructor(){

    }
}
