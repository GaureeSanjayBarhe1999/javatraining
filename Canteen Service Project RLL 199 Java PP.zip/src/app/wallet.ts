export class Wallet {
    public cus_id:number;
    public wal_id:number;
    public wal_src:string;
    public wal_amount:number;
}